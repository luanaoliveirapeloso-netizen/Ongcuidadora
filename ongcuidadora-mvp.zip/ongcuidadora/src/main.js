import './style.css';

const app = document.querySelector('#app');
const TOKEN_KEY = 'ongcuidadora_token';
const USER_KEY = 'ongcuidadora_usuario';

// ---------- Utilidades ----------
const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const dataBR = (iso) => (iso ? iso.slice(0, 10).split('-').reverse().join('/') : '');

function idade(iso) {
  const n = new Date(iso + 'T00:00:00');
  const h = new Date();
  let i = h.getFullYear() - n.getFullYear();
  if (h < new Date(h.getFullYear(), n.getMonth(), n.getDate())) i--;
  return i;
}

async function api(caminho, opcoes = {}) {
  const token = localStorage.getItem(TOKEN_KEY);
  const res = await fetch(`/api${caminho}`, {
    ...opcoes,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: opcoes.body ? JSON.stringify(opcoes.body) : undefined,
  });
  if (res.status === 204) return null;
  const dados = await res.json().catch(() => ({}));
  if (res.status === 401 && token) {
    sair(dados.erro || 'Sessão expirada. Faça login novamente.');
    throw new Error(dados.erro);
  }
  if (!res.ok) throw new Error(dados.erro || `Erro ${res.status}`);
  return dados;
}

function avisar(texto, tipo = 'ok') {
  const el = document.querySelector('#aviso');
  if (!el) return;
  el.textContent = texto;
  el.className = `aviso ${tipo}`;
  clearTimeout(avisar.t);
  avisar.t = setTimeout(() => (el.className = 'aviso'), 4000);
}

const lerForm = (form) => Object.fromEntries(new FormData(form).entries());

// ---------- Login ----------
function telaLogin(mensagem = '') {
  app.innerHTML = `
    <main class="login">
      <h1>OngCuidadora</h1>
      <p class="sub">Agenda de cuidados e voluntários</p>
      <form id="form-login">
        <label>E-mail <input name="email" type="email" required autocomplete="username" /></label>
        <label>Senha <input name="senha" type="password" required autocomplete="current-password" /></label>
        <button type="submit">Entrar</button>
        <p class="erro" id="erro-login">${esc(mensagem)}</p>
      </form>
    </main>`;
  document.querySelector('#form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const { token, usuario } = await api('/auth/login', { method: 'POST', body: lerForm(e.target) });
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(usuario));
      telaPrincipal();
    } catch (err) {
      document.querySelector('#erro-login').textContent = err.message;
    }
  });
}

function sair(mensagem = '') {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  telaLogin(mensagem);
}

// ---------- Estrutura principal ----------
const abas = { atendimentos: 'Atendimentos', assistidos: 'Assistidos', voluntarios: 'Voluntários' };

function telaPrincipal(aba = 'atendimentos') {
  const usuario = JSON.parse(localStorage.getItem(USER_KEY) || '{}');
  app.innerHTML = `
    <header class="topo">
      <strong class="marca">OngCuidadora</strong>
      <nav>${Object.entries(abas)
        .map(([k, v]) => `<button class="aba ${k === aba ? 'ativa' : ''}" data-aba="${k}">${v}</button>`)
        .join('')}</nav>
      <div class="conta">
        <span>${esc(usuario.nome)}</span>
        <button id="sair" class="secundario">Sair</button>
      </div>
    </header>
    <div id="aviso" class="aviso" role="status"></div>
    <main id="conteudo" class="conteudo"></main>
    <footer class="rodape" id="status-api">Status da API: verificando…</footer>`;

  document.querySelectorAll('.aba').forEach((b) => b.addEventListener('click', () => telaPrincipal(b.dataset.aba)));
  document.querySelector('#sair').addEventListener('click', () => sair());

  fetch('/api/health')
    .then((r) => r.json())
    .then((d) => {
      document.querySelector('#status-api').textContent =
        `Status da API: ${d.status} · ${new Date(d.timestamp).toLocaleString('pt-BR')}`;
    })
    .catch(() => (document.querySelector('#status-api').textContent = 'Status da API: indisponível'));

  ({ atendimentos: telaAtendimentos, assistidos: telaAssistidos, voluntarios: telaVoluntarios })[aba]();
}

// ---------- Cadastro genérico (assistidos e voluntários) ----------
function telaCadastro({ caminho, chave, titulo, campos, colunas }) {
  const conteudo = document.querySelector('#conteudo');
  let editando = null;

  conteudo.innerHTML = `
    <section class="painel">
      <h2 id="titulo-form">Novo ${titulo}</h2>
      <form id="form-cad" class="grade">
        ${campos
          .map(
            (c) => `<label>${c.rotulo}${c.obrigatorio ? '' : ' <small>(opcional)</small>'}
              <input name="${c.nome}" type="${c.tipo || 'text'}" ${c.obrigatorio ? 'required' : ''} maxlength="${c.max || 150}" /></label>`
          )
          .join('')}
        <div class="acoes">
          <button type="submit" id="salvar">Cadastrar</button>
          <button type="button" id="cancelar" class="secundario" hidden>Cancelar edição</button>
        </div>
      </form>
    </section>
    <section class="painel">
      <h2>${titulo[0].toUpperCase() + titulo.slice(1)}s cadastrados</h2>
      <div class="tabela-wrap"><table>
        <thead><tr>${colunas.map((c) => `<th>${c.rotulo}</th>`).join('')}<th></th></tr></thead>
        <tbody id="linhas"><tr><td colspan="9">Carregando…</td></tr></tbody>
      </table></div>
    </section>`;

  const form = document.querySelector('#form-cad');

  function limpar() {
    editando = null;
    form.reset();
    document.querySelector('#titulo-form').textContent = `Novo ${titulo}`;
    document.querySelector('#salvar').textContent = 'Cadastrar';
    document.querySelector('#cancelar').hidden = true;
  }

  async function carregar() {
    try {
      const lista = await api(`/${caminho}`);
      const tbody = document.querySelector('#linhas');
      if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="9" class="vazio">Nenhum ${titulo} ainda. Use o formulário acima para cadastrar.</td></tr>`;
        return;
      }
      tbody.innerHTML = lista
        .map(
          (item) => `<tr>
            ${colunas.map((c) => `<td>${esc(c.mostrar ? c.mostrar(item) : item[c.nome])}</td>`).join('')}
            <td class="botoes">
              <button class="link" data-editar="${item[chave]}">Editar</button>
              <button class="link perigo" data-excluir="${item[chave]}">Excluir</button>
            </td></tr>`
        )
        .join('');
      tbody.querySelectorAll('[data-editar]').forEach((b) =>
        b.addEventListener('click', () => {
          const item = lista.find((i) => String(i[chave]) === b.dataset.editar);
          editando = item[chave];
          campos.forEach((c) => (form.elements[c.nome].value = (item[c.nome] || '').slice(0, c.tipo === 'date' ? 10 : 999)));
          document.querySelector('#titulo-form').textContent = `Editar ${titulo}`;
          document.querySelector('#salvar').textContent = 'Salvar alterações';
          document.querySelector('#cancelar').hidden = false;
          form.scrollIntoView({ behavior: 'smooth' });
        })
      );
      tbody.querySelectorAll('[data-excluir]').forEach((b) =>
        b.addEventListener('click', async () => {
          if (!confirm(`Excluir este ${titulo}?`)) return;
          try {
            await api(`/${caminho}/${b.dataset.excluir}`, { method: 'DELETE' });
            avisar(`${titulo[0].toUpperCase() + titulo.slice(1)} excluído.`);
            carregar();
          } catch (err) {
            avisar(err.message, 'erro');
          }
        })
      );
    } catch (err) {
      avisar(err.message, 'erro');
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      if (editando) {
        await api(`/${caminho}/${editando}`, { method: 'PUT', body: lerForm(form) });
        avisar('Alterações salvas.');
      } else {
        await api(`/${caminho}`, { method: 'POST', body: lerForm(form) });
        avisar(`${titulo[0].toUpperCase() + titulo.slice(1)} cadastrado.`);
      }
      limpar();
      carregar();
    } catch (err) {
      avisar(err.message, 'erro');
    }
  });
  document.querySelector('#cancelar').addEventListener('click', limpar);
  carregar();
}

function telaAssistidos() {
  telaCadastro({
    caminho: 'assistidos',
    chave: 'id_assistido',
    titulo: 'assistido',
    campos: [
      { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
      { nome: 'data_nascimento', rotulo: 'Data de nascimento', tipo: 'date', obrigatorio: true },
      { nome: 'telefone_contato', rotulo: 'Telefone de contato', tipo: 'tel', obrigatorio: true, max: 20 },
      { nome: 'bairro', rotulo: 'Bairro', obrigatorio: true, max: 80 },
    ],
    colunas: [
      { nome: 'nome', rotulo: 'Nome' },
      { rotulo: 'Idade', mostrar: (i) => `${idade(i.data_nascimento)} anos` },
      { nome: 'telefone_contato', rotulo: 'Telefone' },
      { nome: 'bairro', rotulo: 'Bairro' },
    ],
  });
}

function telaVoluntarios() {
  telaCadastro({
    caminho: 'voluntarios',
    chave: 'id_voluntario',
    titulo: 'voluntário',
    campos: [
      { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
      { nome: 'telefone', rotulo: 'Telefone', tipo: 'tel', obrigatorio: true, max: 20 },
      { nome: 'email', rotulo: 'E-mail', tipo: 'email', max: 100 },
    ],
    colunas: [
      { nome: 'nome', rotulo: 'Nome' },
      { nome: 'telefone', rotulo: 'Telefone' },
      { nome: 'email', rotulo: 'E-mail' },
    ],
  });
}

// ---------- Atendimentos ----------
async function telaAtendimentos() {
  const conteudo = document.querySelector('#conteudo');
  conteudo.innerHTML = '<p>Carregando…</p>';

  let assistidos, voluntarios, tipos;
  try {
    [assistidos, voluntarios, tipos] = await Promise.all([api('/assistidos'), api('/voluntarios'), api('/tipos-cuidado')]);
  } catch (err) {
    conteudo.innerHTML = '';
    return avisar(err.message, 'erro');
  }

  const opcoes = (lista, chave) => lista.map((i) => `<option value="${i[chave]}">${esc(i.nome)}</option>`).join('');

  conteudo.innerHTML = `
    <section class="painel">
      <h2>Agendar atendimento</h2>
      <form id="form-at" class="grade">
        <label>Assistido <select name="id_assistido" required><option value="">Escolha…</option>${opcoes(assistidos, 'id_assistido')}</select></label>
        <label>Voluntário <select name="id_voluntario" required><option value="">Escolha…</option>${opcoes(voluntarios, 'id_voluntario')}</select></label>
        <label>Data <input name="data_atendimento" type="date" required /></label>
        <label>Hora <input name="hora_inicio" type="time" required /></label>
        <label>Duração (minutos) <input name="duracao_minutos" type="number" min="1" step="1" value="60" required /></label>
        <fieldset class="tipos"><legend>Tipos de cuidado</legend>
          ${tipos.map((t) => `<label class="check"><input type="checkbox" name="tipo" value="${t.id_tipo_cuidado}" /> ${esc(t.nome)}</label>`).join('')}
        </fieldset>
        <label class="largo">Observação <small>(opcional)</small><textarea name="observacao" maxlength="500" rows="2"></textarea></label>
        <div class="acoes"><button type="submit">Agendar</button></div>
      </form>
    </section>
    <section class="painel">
      <h2>Atendimentos</h2>
      <div class="tabela-wrap"><table>
        <thead><tr><th>Data</th><th>Assistido</th><th>Voluntário</th><th>Cuidados</th><th>Status</th><th></th></tr></thead>
        <tbody id="linhas-at"></tbody>
      </table></div>
    </section>`;

  async function carregar() {
    try {
      const lista = await api('/atendimentos');
      const tbody = document.querySelector('#linhas-at');
      if (!lista.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="vazio">Nenhum atendimento ainda. Agende o primeiro no formulário acima.</td></tr>';
        return;
      }
      tbody.innerHTML = lista
        .map(
          (a) => `<tr>
            <td>${dataBR(a.data_atendimento)}<br><small>${a.hora_inicio.slice(0, 5)} · ${a.duracao_minutos} min</small></td>
            <td>${esc(a.assistido)}</td>
            <td>${esc(a.voluntario)}</td>
            <td>${esc(a.cuidados)}${a.observacao ? `<br><small>${esc(a.observacao)}</small>` : ''}</td>
            <td><select class="status st-${a.status}" data-status="${a.id_atendimento}">
              ${['agendado', 'realizado', 'cancelado'].map((s) => `<option ${s === a.status ? 'selected' : ''}>${s}</option>`).join('')}
            </select></td>
            <td class="botoes"><button class="link perigo" data-excluir="${a.id_atendimento}">Excluir</button></td>
          </tr>`
        )
        .join('');
      tbody.querySelectorAll('[data-status]').forEach((s) =>
        s.addEventListener('change', async () => {
          try {
            await api(`/atendimentos/${s.dataset.status}/status`, { method: 'PATCH', body: { status: s.value } });
            s.className = `status st-${s.value}`;
            avisar('Status atualizado.');
          } catch (err) {
            avisar(err.message, 'erro');
          }
        })
      );
      tbody.querySelectorAll('[data-excluir]').forEach((b) =>
        b.addEventListener('click', async () => {
          if (!confirm('Excluir este atendimento?')) return;
          try {
            await api(`/atendimentos/${b.dataset.excluir}`, { method: 'DELETE' });
            avisar('Atendimento excluído.');
            carregar();
          } catch (err) {
            avisar(err.message, 'erro');
          }
        })
      );
    } catch (err) {
      avisar(err.message, 'erro');
    }
  }

  document.querySelector('#form-at').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const dados = lerForm(form);
    dados.tipos = [...form.querySelectorAll('input[name="tipo"]:checked')].map((c) => Number(c.value));
    delete dados.tipo;
    if (!dados.tipos.length) return avisar('Escolha ao menos um tipo de cuidado.', 'erro');
    try {
      await api('/atendimentos', { method: 'POST', body: dados });
      avisar('Atendimento agendado.');
      form.reset();
      carregar();
    } catch (err) {
      avisar(err.message, 'erro');
    }
  });

  carregar();
}

// ---------- Início ----------
if (localStorage.getItem(TOKEN_KEY)) telaPrincipal();
else telaLogin();
