# OngCuidadora

Sistema web da OngCuidadora para organizar os atendimentos dos voluntários cuidadores às pessoas assistidas.
Projeto Integrador Extensionista II: front-end com Vite+ e API Express com MySQL.

## O que o sistema faz

- Login com e-mail e senha (token JWT, senha guardada com bcrypt) e botão Sair
- Cadastro, edição e exclusão de assistidos e de voluntários
- Agendamento de atendimentos com um ou mais tipos de cuidado
- Mudança de status do atendimento (agendado, realizado, cancelado) e exclusão
- Rotas da API protegidas: sem token, respondem 401

## Requisitos

- Node.js 20.6 ou superior
- MySQL 8 (ou MariaDB) rodando em localhost
- Vite+ (`vp`)

## Como rodar

```bash
git clone https://github.com/SEU_USUARIO/ongcuidadora.git
cd ongcuidadora
vp install
```

No MySQL (Workbench ou terminal `mysql -u root -p`):

```sql
SOURCE database/schema.sql;
SOURCE database/seed.sql;
```

Copie `.env.example` para `.env` e preencha `DB_PASSWORD` (senha do seu MySQL) e `JWT_SECRET` (um texto longo qualquer).

Terminal 1 (API):

```bash
vp run api
```

Terminal 2 (front-end):

```bash
vp dev
```

Abra http://localhost:5173

No Windows, também dá para dar dois cliques em `iniciar.bat`, que abre a API e o site.

## Usuário de demonstração

| E-mail | Senha |
|---|---|
| admin@ongcuidadora.org | cuidadora123 |

## Banco de dados

- `database/schema.sql`: cria o banco do zero (pode rodar várias vezes)
- `database/seed.sql`: usuário de demonstração e dados de exemplo

Tabelas: `usuario`, `voluntario`, `assistido`, `tipo_cuidado`, `atendimento` e `atendimento_cuidado` (N:N entre atendimento e tipo de cuidado), além de `doacao`.

## Rotas da API

| Método | Rota | Login |
|---|---|---|
| GET | `/api/health` | não |
| POST | `/api/auth/login` | não |
| GET, POST | `/api/assistidos` | sim |
| PUT, DELETE | `/api/assistidos/:id` | sim |
| GET, POST | `/api/voluntarios` | sim |
| PUT, DELETE | `/api/voluntarios/:id` | sim |
| GET | `/api/tipos-cuidado` | sim |
| GET, POST | `/api/atendimentos` | sim |
| PATCH | `/api/atendimentos/:id/status` | sim |
| DELETE | `/api/atendimentos/:id` | sim |
