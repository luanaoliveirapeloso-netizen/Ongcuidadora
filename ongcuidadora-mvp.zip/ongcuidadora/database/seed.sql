-- OngCuidadora · seed.sql
-- Dados de exemplo. Rode depois do schema.sql.
SET NAMES utf8mb4;
USE ongcuidadora;

-- Usuário de demonstração: admin@ongcuidadora.org / cuidadora123 (senha guardada com bcrypt)
INSERT INTO usuario (nome, email, senha_hash, perfil) VALUES
  ('Coordenação OngCuidadora', 'admin@ongcuidadora.org',
   '$2a$10$8ikcw361u3lhQCFDw0wVguVL2mTki2ZK0izWTwnen5TUo3CbE00kS', 'admin');

INSERT INTO tipo_cuidado (nome, descricao) VALUES
  ('Companhia e conversa', 'Visita para conversar, ler ou fazer atividades juntos'),
  ('Acompanhamento a consultas', 'Ir junto a consultas médicas e exames'),
  ('Ajuda com medicação', 'Organizar horários e conferir a medicação do dia'),
  ('Compras e recados', 'Fazer compras de mercado, farmácia ou pagar contas'),
  ('Caminhada assistida', 'Caminhada curta com apoio');

INSERT INTO voluntario (nome, email, telefone) VALUES
  ('Ana Paula Ribeiro', 'ana.ribeiro@exemplo.com', '(11) 98888-1001'),
  ('Bruno Santos', 'bruno.santos@exemplo.com', '(11) 98888-1002'),
  ('Carla Mendes', NULL, '(11) 98888-1003');

INSERT INTO assistido (nome, data_nascimento, telefone_contato, bairro) VALUES
  ('Dona Maria Aparecida', '1941-03-12', '(11) 3333-2001', 'Vila Mariana'),
  ('Seu José Carlos', '1938-08-25', '(11) 3333-2002', 'Mooca'),
  ('Dona Helena Souza', '1945-11-02', '(11) 3333-2003', 'Ipiranga');

INSERT INTO atendimento (id_assistido, id_voluntario, data_atendimento, hora_inicio, duracao_minutos, status, observacao) VALUES
  (1, 1, '2026-11-20', '14:00', 90, 'realizado', 'Jogamos dominó e organizamos os remédios da semana.'),
  (2, 2, '2026-11-24', '09:30', 120, 'realizado', NULL),
  (3, 3, '2026-12-02', '10:00', 60, 'agendado', 'Levar a receita nova.');

INSERT INTO atendimento_cuidado (id_atendimento, id_tipo_cuidado) VALUES
  (1, 1), (1, 3),
  (2, 2),
  (3, 4), (3, 5);
