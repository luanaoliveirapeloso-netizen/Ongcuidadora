import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool } from './db.js';
import { exigirLogin } from './auth.js';

const app = express();
const PORT = process.env.API_PORT || 3000;

if (!process.env.JWT_SECRET) {
  console.error('Defina JWT_SECRET no arquivo .env');
  process.exit(1);
}

app.use(express.json());

// Envolve rotas async para que erros cheguem ao tratador no fim do arquivo
const rota = (fn) => (req, res, next) => fn(req, res, next).catch(next);

// ---------- Rotas públicas ----------
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.post('/api/auth/login', rota(async (req, res) => {
  const { email, senha } = req.body || {};
  if (!email || !senha) {
    return res.status(400).json({ erro: 'Informe e-mail e senha.' });
  }
  const [linhas] = await pool.query(
    'SELECT id_usuario, nome, email, senha_hash, perfil FROM usuario WHERE email = ? AND ativo = TRUE',
    [email]
  );
  const usuario = linhas[0];
  if (!usuario || !(await bcrypt.compare(senha, usuario.senha_hash))) {
    return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
  }
  const token = jwt.sign(
    { id: usuario.id_usuario, nome: usuario.nome, perfil: usuario.perfil },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );
  res.json({ token, usuario: { nome: usuario.nome, email: usuario.email, perfil: usuario.perfil } });
}));

// ---------- Daqui para baixo, só com login ----------
app.use('/api', exigirLogin);

// Cadastros simples: assistidos e voluntários
function crud(caminho, tabela, chave, campos, obrigatorios) {
  app.get(`/api/${caminho}`, rota(async (req, res) => {
    const [linhas] = await pool.query(`SELECT * FROM ${tabela} ORDER BY nome`);
    res.json(linhas);
  }));

  const validar = (corpo) => obrigatorios.filter((c) => !String(corpo?.[c] ?? '').trim());

  app.post(`/api/${caminho}`, rota(async (req, res) => {
    const faltando = validar(req.body);
    if (faltando.length) return res.status(400).json({ erro: `Preencha: ${faltando.join(', ')}.` });
    const valores = campos.map((c) => req.body[c] || null);
    const [r] = await pool.query(
      `INSERT INTO ${tabela} (${campos.join(', ')}) VALUES (${campos.map(() => '?').join(', ')})`,
      valores
    );
    res.status(201).json({ id: r.insertId });
  }));

  app.put(`/api/${caminho}/:id`, rota(async (req, res) => {
    const faltando = validar(req.body);
    if (faltando.length) return res.status(400).json({ erro: `Preencha: ${faltando.join(', ')}.` });
    const valores = campos.map((c) => req.body[c] || null);
    const [r] = await pool.query(
      `UPDATE ${tabela} SET ${campos.map((c) => `${c} = ?`).join(', ')} WHERE ${chave} = ?`,
      [...valores, req.params.id]
    );
    if (!r.affectedRows) return res.status(404).json({ erro: 'Registro não encontrado.' });
    res.json({ ok: true });
  }));

  app.delete(`/api/${caminho}/:id`, rota(async (req, res) => {
    const [r] = await pool.query(`DELETE FROM ${tabela} WHERE ${chave} = ?`, [req.params.id]);
    if (!r.affectedRows) return res.status(404).json({ erro: 'Registro não encontrado.' });
    res.status(204).end();
  }));
}

crud('assistidos', 'assistido', 'id_assistido',
  ['nome', 'data_nascimento', 'telefone_contato', 'bairro'],
  ['nome', 'data_nascimento', 'telefone_contato', 'bairro']);

crud('voluntarios', 'voluntario', 'id_voluntario',
  ['nome', 'email', 'telefone'],
  ['nome', 'telefone']);

app.get('/api/tipos-cuidado', rota(async (req, res) => {
  const [linhas] = await pool.query('SELECT * FROM tipo_cuidado ORDER BY nome');
  res.json(linhas);
}));

// Atendimentos (com vários tipos de cuidado: relacionamento N:N)
app.get('/api/atendimentos', rota(async (req, res) => {
  const [linhas] = await pool.query(`
    SELECT a.id_atendimento, a.data_atendimento, a.hora_inicio, a.duracao_minutos,
           a.status, a.observacao,
           s.nome AS assistido, v.nome AS voluntario,
           GROUP_CONCAT(t.nome ORDER BY t.nome SEPARATOR ', ') AS cuidados
    FROM atendimento a
    JOIN assistido  s ON s.id_assistido  = a.id_assistido
    JOIN voluntario v ON v.id_voluntario = a.id_voluntario
    LEFT JOIN atendimento_cuidado ac ON ac.id_atendimento = a.id_atendimento
    LEFT JOIN tipo_cuidado t ON t.id_tipo_cuidado = ac.id_tipo_cuidado
    GROUP BY a.id_atendimento
    ORDER BY a.data_atendimento DESC, a.hora_inicio DESC`);
  res.json(linhas);
}));

app.post('/api/atendimentos', rota(async (req, res) => {
  const { id_assistido, id_voluntario, data_atendimento, hora_inicio, duracao_minutos, observacao, tipos } = req.body || {};
  if (!id_assistido || !id_voluntario || !data_atendimento || !hora_inicio || duracao_minutos === undefined || duracao_minutos === '') {
    return res.status(400).json({ erro: 'Preencha assistido, voluntário, data, hora e duração.' });
  }
  if (!(Number(duracao_minutos) > 0)) {
    return res.status(400).json({ erro: 'A duração deve ser maior que zero.' });
  }
  if (!Array.isArray(tipos) || tipos.length === 0) {
    return res.status(400).json({ erro: 'Escolha ao menos um tipo de cuidado.' });
  }
  const conexao = await pool.getConnection();
  try {
    await conexao.beginTransaction();
    const [r] = await conexao.query(
      `INSERT INTO atendimento (id_assistido, id_voluntario, data_atendimento, hora_inicio, duracao_minutos, observacao)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id_assistido, id_voluntario, data_atendimento, hora_inicio, duracao_minutos, observacao || null]
    );
    await conexao.query(
      'INSERT INTO atendimento_cuidado (id_atendimento, id_tipo_cuidado) VALUES ?',
      [tipos.map((t) => [r.insertId, t])]
    );
    await conexao.commit();
    res.status(201).json({ id: r.insertId });
  } catch (erro) {
    await conexao.rollback();
    throw erro;
  } finally {
    conexao.release();
  }
}));

app.patch('/api/atendimentos/:id/status', rota(async (req, res) => {
  if (!['agendado', 'realizado', 'cancelado'].includes(req.body?.status)) {
    return res.status(400).json({ erro: 'Status inválido.' });
  }
  const [r] = await pool.query(
    'UPDATE atendimento SET status = ? WHERE id_atendimento = ?',
    [req.body?.status, req.params.id]
  );
  if (!r.affectedRows) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
  res.json({ ok: true });
}));

app.delete('/api/atendimentos/:id', rota(async (req, res) => {
  const [r] = await pool.query('DELETE FROM atendimento WHERE id_atendimento = ?', [req.params.id]);
  if (!r.affectedRows) return res.status(404).json({ erro: 'Atendimento não encontrado.' });
  res.status(204).end();
}));

// ---------- Tratamento de erros ----------
app.use((erro, req, res, next) => {
  const mensagens = {
    ER_DUP_ENTRY: [409, 'Já existe um cadastro com esse e-mail.'],
    ER_ROW_IS_REFERENCED_2: [409, 'Não é possível excluir: há atendimentos ligados a este cadastro.'],
    ER_CHECK_CONSTRAINT_VIOLATED: [400, 'Valor inválido em algum campo.'],
    ER_CONSTRAINT_FAILED: [400, 'Valor inválido em algum campo.'],
    ER_NO_REFERENCED_ROW_2: [400, 'Assistido, voluntário ou tipo de cuidado inexistente.'],
    ECONNREFUSED: [503, 'Banco de dados indisponível. Verifique se o MySQL está rodando.'],
    ER_ACCESS_DENIED_ERROR: [503, 'Usuário ou senha do MySQL incorretos no .env.'],
    ER_BAD_DB_ERROR: [503, 'Banco ongcuidadora não encontrado. Rode o schema.sql.'],
  };
  const violouCheck = erro.errno === 3819 || erro.errno === 4025; // MySQL / MariaDB
  const [status, erroMsg] = violouCheck
    ? [400, 'Valor inválido em algum campo.']
    : mensagens[erro.code] || [500, 'Erro interno no servidor.'];
  if (status === 500) console.error(erro);
  res.status(status).json({ erro: erroMsg });
});

app.listen(PORT, () => {
  console.log(`API rodando em http://localhost:${PORT}`);
});
